#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "defs.h"
#include "parser.h"
#include "structs.h"
#include "montador.h"

/* Versao do montador */
#define VERSAO "0.1"

/* Arquivos de entrada e saida */
FILE *in;
FILE *out;

int main(int argc, char *argv[])
{

    if (argc < 2){
        printf("Montador :\nUso : %s <arquivo texto de entrada> [<arquivo de saida>]\n",argv[0]);
#ifndef __linux__
        system("pause");
#endif
        exit(1);
    }
    int l;
    char* o;//output file nome
//processamento do input
    if(argc==2){
	    //input so tem arquivo de entrada. O nome do arquivo de saida eh igual ao de entrada trocando a extensao .asm (se tiver) por .mif, senao adicionando a extensao .mif
	    l=strlen(argv[1]);
	    //string nao eh grande o suficiente para ter a extensao .asm
	    if(l<4){
		    o=(char*)malloc((4+l+1)*sizeof(char));
		    strcpy(o,argv[1]);
		    strcat(o,".mif");
		    //coeficiente de cagaco, pra ter ctz q a string termina
		    o[l]='\0';
	    }
	    //string tem a extensao .asm
	    else if(argv[1][l-1]=='m' && argv[1][l-2]=='s' && argv[1][l-3]=='a' && argv[1][l-4]=='.'){
		    o=(char*)malloc((l+1)*sizeof(char));
		    strcpy(o,argv[1]);
		    o[l]='\0';
		    //trocando a extensao
		    o[l-1]='f';
		    o[l-2]='i';
		    o[l-3]='m';
	    }
	    //string eh grande, mas n tem a extensao
	    else{
		    o=(char*)malloc((l+4+1)*sizeof(char));
		    strcpy(o,argv[1]);
		    o[l]='\0';
	    }
    }else{
	    //mudar o ponteiro ta bom o suficiente
	    o=argv[2];
    }

    printf("Montador v.%s\n",VERSAO);

    CarregaPrograma(argv[1]);

    out = fopen(o,"w");

    if (out == NULL){
        parser_Abort("Impossivel criar arquivo para escrita!");
    }

    Montar();

    fclose(out);

    if(argc==2){
	    free(o);
    }

    return 0;

}
